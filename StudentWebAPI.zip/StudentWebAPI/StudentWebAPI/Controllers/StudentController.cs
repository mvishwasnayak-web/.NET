﻿using Microsoft.AspNetCore.Mvc;
using StudentWebAPI.Models;
using System.Collections.Generic;
using System.Linq;

namespace StudentWebAPI.Controllers
{
    public class StudentController : Controller
    {
        // In-memory store for demo
        private static readonly List<Student> _students = new List<Student>
        {
            new Student { Id = 1, Name = "Rahul", ClassName = "BCA-2", Cn = 78, Ada = 85, Ml = 72 }
        };

        // GET: /Student
        public IActionResult Index()
        {
            return View(_students);
        }

        // POST: /Student/Add
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Add([FromForm] Student model)
        {
            if (!ModelState.IsValid)
            {
                // On validation error, return Index with the current list (you can show errors in the view)
                return View("Index", _students);
            }

            model.Id = _students.Any() ? _students.Max(s => s.Id) + 1 : 1;
            _students.Add(model);
            return RedirectToAction(nameof(Index));
        }

        // Optional: a JSON-friendly endpoint if you want to POST JSON (API style)
        [HttpPost]
        [Route("api/student/add")]
        public IActionResult AddJson([FromBody] Student model)
        {
            if (model == null) return BadRequest();
            model.Id = _students.Any() ? _students.Max(s => s.Id) + 1 : 1;
            _students.Add(model);
            return CreatedAtAction(nameof(Index), new { id = model.Id }, model);
        }
    }
}
