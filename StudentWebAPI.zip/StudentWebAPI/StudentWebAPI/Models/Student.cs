﻿using System;

namespace StudentWebAPI.Models
{
    public class Student
    {
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public string ClassName { get; set; } = string.Empty;

        public int Cn { get; set; }   // Computer Networks
        public int Ada { get; set; }  // ADA
        public int Ml { get; set; }   // Machine Learning

        public int Total => Cn + Ada + Ml;
        public double Percentage => Math.Round((Total / 300.0) * 100, 2);
    }
}
